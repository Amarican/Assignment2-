import gradio as gr
import tensorflow as tf
import numpy as np
from tensorflow.keras.models import load_model

# Load your trained generator model.
# Make sure 'generator_model.h5' is in the repository root.
GENERATOR_PATH = "generator_model.h5"
generator = load_model(GENERATOR_PATH)

# Adjust LATENT_DIM if necessary based on your model's training.
LATENT_DIM = 128

def generate_image():
    # Generate random noise with the expected shape
    noise = tf.random.normal([1, 1, 1, LATENT_DIM])
    generated_image = generator(noise, training=False)
    
    # Rescale image values from [-1, 1] to [0, 1]
    img = (generated_image.numpy().squeeze() + 1) / 2.0
    
    # Return the image (Gradio accepts numpy arrays for images)
    return img

# Create a Gradio interface for your model.
iface = gr.Interface(
    fn=generate_image,
    inputs=[],
    outputs=gr.Image(type="numpy", label="Generated Image"),
    title="Generative Model Demo",
    description="Click the button to generate an image using the generator model."
)

if __name__ == "__main__":
    iface.launch()
